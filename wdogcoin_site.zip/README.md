# Wardog (WDOG)

**WDOG** is the ultimate meme coin for those who live by the code of war. Aggressive, bold, and built for domination.

## 💣 About WDOG
Wardog brings the military spirit to the world of crypto. Meme with might.

## 🔘 How to Buy
Click the "Buy WDOG" button on the website. It opens PancakeSwap preloaded with the contract address.

## 🧠 Hosting Instructions
1. Create a public repo named `wdogcoin` on GitHub
2. Upload these files
3. Go to Settings > Pages > Source: `main` branch, root folder
4. Your site will be live at: `https://<your-github-username>.github.io/wdogcoin`

## 🐕 Join the Army
Wardog isn’t just a token. It’s a movement.
